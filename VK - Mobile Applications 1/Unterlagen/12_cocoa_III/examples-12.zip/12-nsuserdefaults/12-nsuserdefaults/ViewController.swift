//
//  ViewController.swift
//  12-nsuserdefaults
//
//  Created by Henrik Stormer on 27.11.15.
//  Copyright © 2015 Henrik Stormer. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //create the key value entry
        NSUserDefaults.standardUserDefaults()
            .setInteger(50, forKey: "MaximumNumberOfConnections");
        
        //and save the entry
        NSUserDefaults.standardUserDefaults().synchronize();
        
        //reading a saved entry is also straightforward
       print(NSUserDefaults.standardUserDefaults()
            .integerForKey("MaximumNumberOfConnections"));  

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

