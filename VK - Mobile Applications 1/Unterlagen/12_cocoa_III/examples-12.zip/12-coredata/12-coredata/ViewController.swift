//
//  ViewController.swift
//  12-coredata
//
//  Created by Henrik Stormer on 27.11.15.
//  Copyright © 2015 Henrik Stormer. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    let managedObjectContext =
    (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext
    
    @IBAction func onAdd(sender: AnyObject) {
  
        //now create a new addresss
        let newPerson = NSEntityDescription.insertNewObjectForEntityForName("Person",
            inManagedObjectContext: managedObjectContext) as! Person
        
        //add some values
        newPerson.firstName = "Elvis"
        newPerson.lastName = "Presley"
        
        //this entity is now stored in our context (but not persisted). However, during
        //a query, this object will be returned!
        
        do {
            try managedObjectContext.save();
        } catch _ {
            print("exception when saving our person");
        }
        
    }
    
    
    @IBAction func onRead(sender: AnyObject) {
        //for reading our storage, do a fetch request
        let fetchRequest = NSFetchRequest(entityName: "Person")
        
        //and read
        do {
        if let fetchResults = try self.managedObjectContext.executeFetchRequest(fetchRequest)
            as? [Person] {
                
                //we now have all addresses in our fetchResults array
                for address in fetchResults {
                    print("firstName: " + address.firstName! +
                        ", lastName: " + address.lastName!);
                }
            }
        }
        catch _ {
            print("exception when reading our person");
        }
    }


    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

