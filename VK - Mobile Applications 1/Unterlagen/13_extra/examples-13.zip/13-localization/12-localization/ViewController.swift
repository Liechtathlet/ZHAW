//
//  ViewController.swift
//  12-localization
//
//  Created by Henrik Stormer on 24.11.15.
//  Copyright © 2015 Henrik Stormer. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var labelToTranslate: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        labelToTranslate.text = NSLocalizedString("MyFirstKey", comment: "")
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

