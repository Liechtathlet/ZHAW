//
//  FirstProjectUITests.swift
//  FirstProjectUITests
//
//  Created by Henrik Stormer on 08.07.15.
//  Copyright © 2015 Henrik Stormer. All rights reserved.
//

import Foundation
import XCTest

class FirstProjectUITests: XCTestCase {
        
    override func setUp() {
        super.setUp()
        
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        // In UI tests it is usually best to stop immediately when a failure occurs.
        continueAfterFailure = false
        // UI tests must launch the application that they test. Doing this in setup will make sure it happens for each test method.
        XCUIApplication().launch()
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        // Use recording to get started writing UI tests.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        print ("testExample started");
        let app = XCUIApplication()
        
        //Iterate over all textfields and print out the accessiblity label
        for (var i : UInt = 0;i < app.textFields.count;i++)  {
            let element : XCUIElement = app.textFields.elementBoundByIndex(i);
            print ("Checking the textfield label: " + element.label);
        }
 
        
        app.toolbars.buttons["Extend"].tap()
        
        let descriptionTextFieldEl = app.textFields["descriptionTextField"]
        descriptionTextFieldEl.tap()
        descriptionTextFieldEl.typeText("Description");
        
        
        let descriptionLabelEl = app.staticTexts["descriptionLabel"];
        descriptionLabelEl.tap()
        
       
   
    
        //check the entered text
        XCTAssertEqual(descriptionTextFieldEl.value as? String, "Description");
        
        //click the button to go back to the 
        //main page
        app.buttons["Button"].tap()
        
        
        print ("testExample ended");
        
    }
    
}
