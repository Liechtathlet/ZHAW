//
//  ViewController.swift
//  12-coredata
//
//  Created by Henrik Stormer on 27.11.15.
//  Copyright © 2015 Henrik Stormer. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var firstName: UITextField!
    @IBOutlet weak var lastName: UITextField!
    @IBOutlet weak var tableView: UITableView!
    
    //member variable to store the read persons
    var readPersons : [Person]?;
    
    //member variable to store the access to core data
    let managedObjectContext =
    (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext
    
    //called when the user clicks "Add"
    @IBAction func onAdd(sender: AnyObject) {
  
        //now create a new addresss
        let newPerson = NSEntityDescription.insertNewObjectForEntityForName("Person",
            inManagedObjectContext: managedObjectContext) as! Person
        
        //add some values
        newPerson.firstName = firstName.text ?? "-"
        newPerson.lastName = lastName.text ?? "-"
 
        //and save it
        do {
            try managedObjectContext.save();
            
            //reset the fields
            firstName.text = ""
            lastName.text = ""
        } catch _ {
            print("exception when saving our person");
        }
        
    }
    
    /**
     Use predicates here....
    */
    @IBAction func onRead(sender: AnyObject) {
        readData()
    }

    func readData() {
        //for reading our storage, do a fetch request
        let fetchRequest = NSFetchRequest(entityName: "Person")
        
        /*
        let predicate = NSPredicate(format: "lastName like ", "P*")
        
        fetchRequest.predicate = predicate
        */
        
        //create a sort descriptor with key and ascending/descending
        let sortDescriptor = NSSortDescriptor(key: "lastName", ascending: true)
        
        //add the sort descriptor to your request
        fetchRequest.sortDescriptors = [sortDescriptor]
        
        
        //and read
        do {
        if let fetchResults = try self.managedObjectContext.executeFetchRequest(fetchRequest)
            as? [Person] {
                
                self.readPersons = fetchResults;
                tableView.reloadData()
            }
        }
        catch _ {
            print("exception when reading our person");
        }
    }

    /**
    Delete an entry
     */
    func deleteEntry(row: Int) {
   
         do {
            self.managedObjectContext.deleteObject(readPersons![row])
                
            try self.managedObjectContext.save()
         }
         catch _ {
             print("exception when deleting a person");
         }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.tableView.dataSource = self
        self.tableView.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if (self.readPersons != nil) {
            return (self.readPersons?.count)!
        }
        return 0;
    }
    
    //return the cell for the provided index
    func tableView(tableView: UITableView,
        cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
            let cell : UITableViewCell = tableView.dequeueReusableCellWithIdentifier("cell")!
            
            cell.textLabel!.text = readPersons![indexPath.row].firstName! + " " +
                readPersons![indexPath.row].lastName!
            
            return cell;
    }
    
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        return true
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        deleteEntry(indexPath.row)
        readData()
    }
}

