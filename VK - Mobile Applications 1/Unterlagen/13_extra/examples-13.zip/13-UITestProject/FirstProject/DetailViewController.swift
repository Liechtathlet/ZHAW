//
//  DetailViewController.swift
//  FirstProject
//
//  Created by Henrik Stormer on 22.07.15.
//  Copyright © 2015 Henrik Stormer. All rights reserved.
//

import Foundation
import UIKit

class DetailViewController: UIViewController {
    
    var value : String = "";
    
    @IBOutlet weak var outputLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    override func viewWillAppear(animated: Bool) {
        outputLabel.text = value;
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func dismissButtonClicked(sender: AnyObject) {
        
        self.dismissViewControllerAnimated(true, completion: nil);
    }
    
}