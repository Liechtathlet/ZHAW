//
//  GreenViewController.swift
//  10-components-navigation
//
//  Created by Henrik Stormer on 12.11.15.
//  Copyright © 2015 Henrik Stormer. All rights reserved.
//

import Foundation
import UIKit

class GreenViewController : UIViewController {
    var message : String = "not initialized"
    
    @IBOutlet weak var messageLabel: UILabel!
    override func viewDidLoad() {
        messageLabel.text = message
    }
    
    
}