//
//  ViewController.swift
//  12-gesture
//
//  Created by Henrik Stormer on 27.11.15.
//  Copyright © 2015 Henrik Stormer. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UIGestureRecognizerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //create a tab gesture for a double click
        let gesture : UITapGestureRecognizer = UITapGestureRecognizer();
        gesture.numberOfTapsRequired = 2;
        
        gesture.delegate = self;
        
        //note the : at the end. We want to create a handler with parameters
        gesture.addTarget(self, action: "handleGesture:");
        
        self.view.addGestureRecognizer(gesture);
    }
    
    func handleGesture(gestureRecognizer: UIGestureRecognizer) {
        print ("gesture active");
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

