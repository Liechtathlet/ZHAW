//
//  ViewController.swift
//  FirstProject
//
//  Created by Henrik Stormer on 08.07.15.
//  Copyright © 2015 Henrik Stormer. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var firstName: UITextField!
  
    @IBAction func onSummaryClicked(sender: AnyObject) {
        self.performSegueWithIdentifier("detailSegue", sender: self);
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        firstName.accessibilityLabel = "firstName"
        firstName.isAccessibilityElement = true;
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if (segue.identifier == "detailSegue") {
            let destinationController = segue.destinationViewController as! DetailViewController;
            destinationController.value = "Hello World"
            
        }
    }

}

