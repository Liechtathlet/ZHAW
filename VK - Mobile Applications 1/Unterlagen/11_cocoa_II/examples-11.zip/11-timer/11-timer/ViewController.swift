//
//  ViewController.swift
//  11-timer
//
//  Created by Henrik Stormer on 12.11.15.
//  Copyright © 2015 Henrik Stormer. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var counter : Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: "mySelectorCall",
            userInfo: nil, repeats: true)
    }
    
    //this method will be called
    func mySelectorCall() {
        print("I am called " + String(counter++));
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

