//
//  CircleView.swift
//  11-example-circle
//
//  Created by Henrik Stormer on 18.11.15.
//  Copyright © 2015 Henrik Stormer. All rights reserved.
//

import Foundation
import UIKit

class CircleView : UIView {
  
    var counter : CGFloat = 1
    var width : CGFloat = 10
    var height : CGFloat = 10
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
    NSTimer.scheduledTimerWithTimeInterval(0.1, target: self, selector: "updateCircle",
            userInfo: nil, repeats: true)
        
    }
    
    override func drawRect(rect: CGRect) {
    //get the context and store it in ctx
    let ctx : CGContextRef = UIGraphicsGetCurrentContext()!;
    
    //set the fill color to green
    CGContextSetFillColorWithColor(ctx, UIColor.greenColor().CGColor);
        
    //and draw the circle
    CGContextFillEllipseInRect(ctx, CGRectMake(40, 40, width, height))
    }
    
    
    
    //this method will be called
    func updateCircle() {
        
        width += counter
        height += counter
        
        self.setNeedsDisplay()
    }
    
}