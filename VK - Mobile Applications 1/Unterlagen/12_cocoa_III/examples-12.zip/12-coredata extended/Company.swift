//
//  Company.swift
//  12-coredata
//
//  Created by Henrik Stormer on 27.11.15.
//  Copyright © 2015 Henrik Stormer. All rights reserved.
//

import Foundation
import CoreData


class Company: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
